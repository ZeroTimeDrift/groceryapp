<?php
require_once 'dbConect.php';
/*
$accountCheck = $db->prepare(" SELECT * from users");
$accountCheck->execute();
$teams = $accountCheck->fetchAll( PDO::FETCH_ASSOC );

foreach( $teams as $team ){
	echo $team['email'];
}
*/


/*
$name = "Joe Bloggs";
$email = "joe@bloggs.net";
$pass = "password123";

$passhash = password_hash($pass, PASSWORD_DEFAULT);

$sql = "INSERT INTO `users` (`name`,`email`,`password`) VALUES (:name, :email, :password)";
$DBMSG = $db->prepare($sql);
	$DBMSG->bindValue(':name', $name);
	$DBMSG->bindValue(':email', $email);
	$DBMSG->bindValue(':password', $passhash);
	$DBMSG->execute();

*/
?>