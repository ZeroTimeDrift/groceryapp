<?php 
require_once '../src/confs.php';
require_once '../src/dbConnect.php';
if (!$_COOKIE['LoggedIn']) {header('Location:'. $siteurl );};


$sql = "SELECT * from shops WHERE shopid = :shopid;";
$getShops = $db->prepare($sql);
$getShops->bindValue(':shopid', $_GET['shopid']);
$getShops->execute();
$shop = $getShops->fetch(PDO::FETCH_ASSOC);

$owner = $shop['owner'];

if ($owner != $_COOKIE['token']) {
  header('Location:'. $siteurl . "/shops" );
}

?>
<!DOCTYPE html>
<html>
<head>
	<title>Edit Store - Wutzu</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <meta http-equiv="x-ua-compatible" content="ie=edge">
 <link rel="stylesheet" type="text/css" href="https://shop.wutzu.com/css/login.css">
 <link rel="icon" type="image/png" href="/img/circle.png">


 <!-- Font Awesome -->
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
 <!-- Bootstrap core CSS -->
 <link href="https://shop.wutzu.com/mdb/css/bootstrap.min.css" rel="stylesheet">
 <!-- Material Design Bootstrap -->
 <link href="https://shop.wutzu.com/mdb/css/mdb.min.css" rel="stylesheet">
 <!-- Your custom styles (optional) -->
 <link href="https://shop.wutzu.com/mdb/css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="https://shop.wutzu.com/mdb/css/addons/mdb-file-upload.css">
</head>
<body>

  <?php require_once '../src/header.php';?>

  - <br>
  - <br>
  - <br>
  <div class="col-md-12">
    <h3>Edit Store - <?php echo $shop['name']; ?></h3>
    <div class="card-deck">
      <div class="card border-primary mb-3" style="max-width: 20rem;">
        <div class="card-header">Shop Identity</div>
        <div class="card-body text-primary">
          <h6 class="card-title">Shop Name</h6>
          <p class="card-text"><input type="text" id="name" class="form-control" value=<?php echo '"'. $shop['name'] .'"'; ?>><span id="tick"/></p>
          <h6 class="card-title">About</h6>
          <textarea class="form-control rounded-0" id="about" rows="3" ><?php echo $shop['about']; ?></textarea><span id="tick"/>
          <h6 class="card-title">Logo</h6>
          <div class="file-upload-wrapper ">
            <input type="file" id="input-file-now-custom-1" class="form-control file_upload" data-default-file=<?php echo '"'. $shop['img'] .'"'; ?> />
          </div>
        </div>
      </div>

      <div class="card border-secondary mb-3" style="max-width: 20rem;">
        <div class="card-header">Shop Address</div>
        <div class="card-body text-secondary">
          <h6 class="card-title">Address Line 1</h6>
          <p class="card-text"><input type="text" id="address_1" class="form-control" value=<?php echo '"'. $shop['address_1'] .'"'; ?>><span id="tick"/></p>
          <h6 class="card-title">Address Line 2</h6>
          <p class="card-text"><input type="text" id="address_2" class="form-control" value=<?php echo '"'. $shop['address_2'] .'"'; ?>><span id="tick"/></p>
          <h6 class="card-title">Address Line 3</h6>
          <p class="card-text"><input type="text" id="address_3" class="form-control" value=<?php echo '"'. $shop['address_3'] .'"'; ?>><span id="tick"/></p>
          <h6 class="card-title">City</h6>
          <p class="card-text"><input type="text" id="city" class="form-control" value=<?php echo '"'. $shop['city'] .'"'; ?>><span id="tick"/></p>
          <h6 class="card-title">Country</h6>
          <p class="card-text"><input type="text" id="country" class="form-control" value=<?php echo '"'. $shop['country'] .'"'; ?>><span id="tick"/></p>
          <h6 class="card-title">Post Code</h6>
          <p class="card-text"><input type="text" id="postcode" class="form-control" value=<?php echo '"'. $shop['postcode'] .'"'; ?>><span id="tick"/></p>
        </div>
      </div>

      <div class="card border-success mb-3" style="max-width: 20rem; max-height: 20rem">
        <div class="card-header">Contact Details</div>
        <div class="card-body text-success">
          <h6 class="card-title">Website</h6>
          <p class="card-text"><input type="text" id="website" class="form-control" value=<?php echo '"'. $shop['website'] .'"'; ?>><span id="tick"/></p>
          <h6 class="card-title">Contact Number</h6>
          <p class="card-text"><input type="text" id="tel" class="form-control" value=<?php echo '"'. $shop['tel'] .'"'; ?>><span id="tick"/></p>
        </div>
      </div>



    </div>
  </div>


  <?php require_once '../src/footer.php';?>
</body>
</html>

<!-- SCRIPTS -->
<!-- JQuery -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/jquery-3.4.1.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/mdb.min.js"></script>
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/addons/mdb-file-upload.min.js"></script>

<script type="text/javascript">

  var MyJSNumVar = <?php Print($shop['shopid']); ?>;

  // or $('#textbox_autopost').blur if you want to do it when the box loses focus
$('.form-control').change(function(){
    console.log($(this).attr('id') + ":" + $(this).val());

    $.ajax({
        type: 'POST',
        // make sure you respect the same origin policy with this url:
        // http://en.wikipedia.org/wiki/Same_origin_policy
        url: 'https://shop.wutzu.com/src/updateShop.php',
        data: { 
            'column_name': $(this).attr('id'), 
            'value': $(this).val(),
            'shopid': MyJSNumVar
        },
        success: function(msg){
            if (msg) {
              toastr.success('Information synced with database');
            } else {
              toastr.warning('There was an issue syncing with the databse, Tray again');
            }
        }
    });
    $(this).addClass('is-valid');
    
});



    $('.file_upload').file_upload();


</script>