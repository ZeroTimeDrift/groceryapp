<?php 

require_once '../src/confs.php';
require_once '../src/dbConnect.php';
if (!$_COOKIE['LoggedIn']) {header('Location:'. $siteurl );};

$sql = "SELECT * from shops WHERE shopid = :shopid;";
$getShops = $db->prepare($sql);
$getShops->bindValue(':shopid', $_GET['shopid']);
$getShops->execute();
$shop = $getShops->fetch(PDO::FETCH_ASSOC);

$sql = "SELECT * from items WHERE shopid = :shopid;";
$getItems = $db->prepare($sql);
$getItems->bindValue(':shopid', $_GET['shopid']);
$getItems->execute();

$itemCount = $getItems->rowCount();

$sql = "SELECT * from orders WHERE shopid = :shopid;";
$getOrders = $db->prepare($sql);
$getOrders->bindValue(':shopid', $_GET['shopid']);
$getOrders->execute();

$orderCount = $getOrders->rowCount();

$sql = "SELECT SUM(totalCost) from orders WHERE shopid = $shopid;";




$sql = "SELECT SUM(totalCost) from orders WHERE shopid = :shopid;";
$totalOrders = $db->prepare($sql);
$totalOrders->bindValue(':shopid', $_GET['shopid']);
$totalOrders->execute();
$totalOrder = $totalOrders->fetch(PDO::FETCH_ASSOC);

$owner = $shop['owner'];

if ($owner != $_COOKIE['token']) {
	header('Location:'. $siteurl . "/shops" );
}


?>
<!DOCTYPE html>
<html>
<head>
	<title><?php echo $shop['name']?> - Wutzu</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<link rel="stylesheet" type="text/css" href="../css/login.css">
	<link rel="icon" type="image/png" href="../img/circle.png">

	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
	<!-- Bootstrap core CSS -->
	<link href="https://shop.wutzu.com/mdb/css/bootstrap.min.css" rel="stylesheet">
	<!-- Material Design Bootstrap -->
	<link href="https://shop.wutzu.com/mdb/css/mdb.min.css" rel="stylesheet">
	<!-- Your custom styles (optional) -->
	<link href="https://shop.wutzu.com/mdb/css/style.css" rel="stylesheet">
</head>
<body>

	<?php require_once '../src/header.php';?>

	- <br>
	- <br>
	- <br>
	<div class="col-md-12">
		<h3>My Shop</h3>
		<div class="row">
			<div class="col-md-3">

				<?php 

				if ($shop['img'] != "") {
					$shopimg = $shop['img'];
				} else {
					$shopimg = "https://shop.wutzu.com/img/blank.png";
				}

				echo '
				<!-- Card Wider -->
				<div class="card card-cascade wider">

				<!-- Card image -->
				<div class="view view-cascade overlay">
				<img  class="card-img-top" src="'.$shopimg.'" alt="Card image cap">
				<a href="#!">
				<div class="mask rgba-white-slight"></div>
				</a>
				</div>

				<!-- Card content -->
				<div class="card-body card-body-cascade text-center">

				<!-- Title -->
				<h4 class="card-title"><strong >'.$shop['name'].'</strong></h4>
				<!-- Subtitle -->
				<h5 class="wutzu-text pb-2"><strong>'.$shop['city'].'</strong></h5>
				<!-- Text -->
				<p class="card-text">About:<br> '.$shop['about'].'</p>
				Address: <br>' .
				$shop['address_1'] .'<br>';
				if ($shop['address_2'] != "") {echo $shop['address_2'] . '<br>';}
				if ($shop['address_3'] != "") {echo $shop['address_3'] . '<br>';}
				if ($shop['city'] != "") {echo $shop['city'] . '<br>';}
				if ($shop['country'] != "") {echo $shop['country'] . '<br>';}
				echo $shop['postcode'] . '<br>';
				echo 'Website: <a href="//'.$shop['website'].'"?>'.$shop['website'].'</a><br>';
				echo 'Tel: <a href="tel:'.$shop['tel'].'"?>'.$shop['tel'].'</a><br>';

				echo '<a href="/shop/'.$shop['shopid'].'/edit" style="color:#a9d728 !important;"><i class="fas fa-edit"></i></a> <a href="" style="color:#dc3545 !important;"><i class="fas fa-trash-alt"></i></a>';

				echo 
				'

				</div>

				</div>
				<!-- Card Wider -->
				';
/*
				$address_str = str_replace(' ', '%20', $shop['address_1'] . "%2C" .$shop['postcode']);
				echo '
				<div style="width: 100%"><iframe width="60%" height="20%" src="https://maps.google.com/maps?width=100%&amp;height=600&amp;hl=en&amp;q='.$address_str.'&amp;ie=UTF8&amp;t=&amp;z=14&amp;iwloc=B&amp;output=embed" frameborder="0" scrolling="no" marginheight="0" marginwidth="0"></iframe></div><br />
				';
*/
				?>
			</div>

			<div class="col-md-6">
				<div class="card-columns">
					<div class="card border-primary mb-3">
						<div class="card-header">Today's Orders <a href=<?php echo '"/shop/'.$shop['shopid'].'/orders"'?> data-toggle="tooltip" title="View All"><i class="fas fa-eye"></i></a></div>
						<div class="card-body text-primary">
							<h5 class="card-title"><?php echo $orderCount?></h5>
							<p class="card-text"></p>
						</div>
					</div>
					<div class="card border-secondary mb-3">
						<div class="card-header">Your Items <a href=<?php echo '"/shop/'.$shop['shopid'].'/items"'?> data-toggle="tooltip" title="View All"><i class="fas fa-eye"></i></a></div>
						<div class="card-body text-secondary">
							<h5 class="card-title"><?php echo $itemCount?></h5>
							<p class="card-text"></p>
						</div>
					</div>
					<div class="card border-success mb-3">
						<div class="card-header">Your Income</div>
						<div class="card-body text-success">
							<h5 class="card-title">£<?php echo $totalOrder['SUM(totalCost)'] ?></h5>
							<p class="card-text"></p>
						</div>
					</div>
				</div>
				<div class="card border-dark">
					<div class="card-body text-dark">
						<h5 class="card-title">Current Orders</h5>
						<?php
						if ($orderCount == 0) {
							echo "You don't have any incomple orders";
						} else {
							echo "<table class='table'>
							<tr><th>Order ID</th><th>Ordered</th><th>Status</th><th>cost</th><th>Quick Actions</th></tr>";
							$orders = $getOrders->fetchAll( PDO::FETCH_ASSOC );
							foreach( $orders as $order ){

								switch ($order['status']) {
									case '0':
										$status = '<span class="text-primary" data-toggle="tooltip" title="You need to approve/accept this order">Order Recieved <i class="fas fa-paper-plane"></i></span>';
										break;
									case '1':
										$status = '<span class="text-danger" data-toggle="tooltip" title="You need to pick this order">Accepted, Needs Picking <i class="fas fa-clipboard-check"></i></span>';
										break;
									case '2':
										$status = '<span class="text-secondary" data-toggle="tooltip" title="This order is currrenly being picked. Sit tight!">Being Picked <i class="fas fa-shopping-cart"></i></span>';
										break;
									case '3':
										$status = '<span class="text-danger" data-toggle="tooltip" title="This order is waiting to be picked up by our driver">Ready for Collection <i class="fas fa-clock"></i></span>';
										break;
									case '4':
										$status = '<span class="text-secondary" data-toggle="tooltip" title="Order is on its way to the customer">En Route <i class="fas fa-car-side"></i></span>';
										break;
									case '5':
										$status = '<span class="text-success" data-toggle="tooltip" title="This order has been succesfully delivered">Delivered <i class="fas fa-home"></i></span>';
										break;
									case '6':
										$status = '<span class="text-danger" data-toggle="tooltip" title="this order was cancled by the customer">Cancled by Customer <i class="fas fa-hand-paper"></i></span>';
										break;
									case '7':
										$status = '<span class="text-danger" data-toggle="tooltip" title="You rejected this order">Rejected <i class="fas fa-ban"></i></span>';
										break;
									default:
										$status = '<span class="text-primary">unknown <i class="fas fa-question"></i></span>';
										break;
								}

								echo "<tr><td>".$order['orderid']."</td><td>".$order['ordertime']."</td><td><b>".$status."</b></td><td>£".$order['totalCost']."</td><td><a href='' data-toggle='tooltip' title='View Order' ><i class='fas fa-eye'></i></a></td></tr>";
							}
							echo "</table>";
						}

						?>
						
					</div>
				</div>
			</div>


			<div class="col-md-3">
				<div class="card">
					<div class="card-body">
						<h5 class="card-title">Your Top Selling Items <a href=<?php echo '"/shop/'.$shop['shopid'].'/items"'?> data-toggle="tooltip" title="View All"><i class="fas fa-eye"></i></a></h5>				
						
						<?php

						$sql = "SELECT * from items WHERE shopid = :shopid ORDER BY sold DESC LIMIT 10;";
						$getItems = $db->prepare($sql);
						$getItems->bindValue(':shopid', $_GET['shopid']);
						$getItems->execute();

						$itemCount = $getItems->rowCount();

						if ($itemCount == 0) {
							echo "You don't have any items in your store yet! Try adding some!";
						} else {
							$items = $getItems->fetchAll( PDO::FETCH_ASSOC );
							echo '<table class="table"><tr><th>Item</th><th>Price</th><th>Sold</th><th>Profit</th></tr>';
							foreach( $items as $item ){

								$profit = $item['sold'] * $item['price'];

								if ($item['price'] >= 1) {
									$price = "£".$item['price'];
								} else {
									$price = ($item['price'] * 100) . "p";
								}

								if ($profit >= 1) {
									$profit = "£".$profit;
								} else {
									$profit = ($profit * 100) . "p";
								}

								echo '<tr><td>'.$item['name'].'</td><td>'.$price.'</td><td>'.$item['sold'].'</td><td>'.$profit.'</td></tr>';
							}
						}
						?>
					</table>

				</div>
			</div>
		</div>
	</div>


	<div class="fixed-action-btn smooth-scroll" style="bottom: 50px; right: 24px;">
		<a href=<?php echo '"/shop/'.$shop['shopid'].'/add-item"'?> class="btn-floating btn-large blue " data-toggle="tooltip" title="Add Items">
			<i class="fas fa-plus"></i>
		</a>
	</div>

</div>
<?php require_once '../src/footer.php';?>
</body>
</html>

<!-- SCRIPTS -->
<!-- JQuery -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/jquery-3.4.1.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/mdb.min.js"></script>


<script type="text/javascript">

  	// Tooltips Initialization
  	$(function () {
  		$('[data-toggle="tooltip"]').tooltip()
  	})

  </script>