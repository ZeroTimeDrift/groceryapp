<?php 
require_once '../src/confs.php';
require_once '../src/dbConnect.php';
if (!$_COOKIE['LoggedIn']) {header('Location:'. $siteurl );};

$sql = "SELECT * from users WHERE token = :token;";
$getUser = $db->prepare($sql);
$getUser->bindValue(':token', $_COOKIE['token']);
$getUser->execute();
$user = $getUser->fetch(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html>
<head>
	<title>Account - Wutzu</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <meta http-equiv="x-ua-compatible" content="ie=edge">
 <link rel="stylesheet" type="text/css" href="https://shop.wutzu.com/css/login.css">
 <link rel="icon" type="image/png" href="/img/circle.png">


 <!-- Font Awesome -->
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
 <!-- Bootstrap core CSS -->
 <link href="https://shop.wutzu.com/mdb/css/bootstrap.min.css" rel="stylesheet">
 <!-- Material Design Bootstrap -->
 <link href="https://shop.wutzu.com/mdb/css/mdb.min.css" rel="stylesheet">
 <!-- Your custom styles (optional) -->
 <link href="https://shop.wutzu.com/mdb/css/style.css" rel="stylesheet">
  <link rel="stylesheet" href="https://shop.wutzu.com/mdb/css/addons/mdb-file-upload.css">
</head>
<body>

  <?php require_once '../src/header.php';?>

  - <br>
  - <br>
  - <br>
  <div class="col-md-12">
    <h3>Account Details</h3>
    <div class="card-deck">
      <div class="card border-primary mb-3" style="max-width: 20rem;">
        <div class="card-header">Your Identity</div>
        <div class="card-body text-primary">
          <h6 class="card-title">Name</h6>
          <p class="card-text"><input type="text" id="name" class="form-control" value=<?php echo '"'. $user['name'] .'"'; ?>><span id="tick"/></p>
          <h6 class="card-title">Email</h6>
          <p class="card-text"><input type="text" id="name" class="form-control" value=<?php echo '"'. $user['email'] .'"'; ?>><span id="tick"/></p>
          <h6 class="card-title">About</h6>
          <textarea class="form-control rounded-0" id="about" rows="3" ><?php echo $user['about']; ?></textarea><span id="tick"/>
          <h6 class="card-title">Icon</h6>
          <div class="file-upload-wrapper ">
            <input type="file" id="input-file-now-custom-1" class="form-control file_upload" data-default-file=<?php echo '"'. $user['img'] .'"'; ?> />
          </div>
        </div>
      </div>

      <div class="card border-secondary mb-3" style="max-width: 20rem;">
        <div class="card-header">Address</div>
        <div class="card-body text-secondary">
          <h6 class="card-title">Address Line 1</h6>
          <p class="card-text"><input type="text" id="address_1" class="form-control" value=<?php echo '"'. $user['address_1'] .'"'; ?>><span id="tick"/></p>
          <h6 class="card-title">Address Line 2</h6>
          <p class="card-text"><input type="text" id="address_2" class="form-control" value=<?php echo '"'. $user['address_2'] .'"'; ?>><span id="tick"/></p>
          <h6 class="card-title">Address Line 3</h6>
          <p class="card-text"><input type="text" id="address_3" class="form-control" value=<?php echo '"'. $user['address_3'] .'"'; ?>><span id="tick"/></p>
          <h6 class="card-title">City</h6>
          <p class="card-text"><input type="text" id="city" class="form-control" value=<?php echo '"'. $user['city'] .'"'; ?>><span id="tick"/></p>
          <h6 class="card-title">Country</h6>
          <p class="card-text"><input type="text" id="country" class="form-control" value=<?php echo '"'. $user['country'] .'"'; ?>><span id="tick"/></p>
          <h6 class="card-title">Post Code</h6>
          <p class="card-text"><input type="text" id="postcode" class="form-control" value=<?php echo '"'. $user['postcode'] .'"'; ?>><span id="tick"/></p>
        </div>
      </div>

      <div class="card border-success mb-3" style="max-width: 20rem; max-height: 20rem">
        <div class="card-header">Contact Details</div>
        <div class="card-body text-success">
          <h6 class="card-title">Website</h6>
          <p class="card-text"><input type="text" id="website" class="form-control" value=<?php echo '"'. $user['website'] .'"'; ?>><span id="tick"/></p>
          <h6 class="card-title">Contact Number</h6>
          <p class="card-text"><input type="text" id="tel" class="form-control" value=<?php echo '"'. $user['tel'] .'"'; ?>><span id="tick"/></p>
        </div>
      </div>

      <div class="card border-danger mb-3" style="max-width: 20rem; max-height: 20rem">
        <div class="card-header ">Change Password</div>
        <div class="card-body text-danger">
          <h6 class="card-title">New Password</h6>
          <p class="card-text"><input type="password" id="pass_1" class="form-control"><span id="tick"/></p>
          <h6 class="card-title">Confirm Password</h6>
          <p class="card-text"><input type="password" id="pass_2" class="form-control"><span id="tick"/></p>
          <button class="btn btn-danger btn-block my-4" type="submit">Change</button>
        </div>
      </div>



    </div>
  </div>


  <?php require_once '../src/footer.php';?>
</body>
</html>

<!-- SCRIPTS -->
<!-- JQuery -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/jquery-3.4.1.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/mdb.min.js"></script>
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/addons/mdb-file-upload.min.js"></script>

<script type="text/javascript">

  var MyJSNumVar = <?php echo( '"' . $_COOKIE['token'] . '"'); ?>;

  // or $('#textbox_autopost').blur if you want to do it when the box loses focus
$('.form-control').change(function(){
    //console.log($(this).attr('id') + ":" + $(this).val());

    $.ajax({
        type: 'POST',
        // make sure you respect the same origin policy with this url:
        // http://en.wikipedia.org/wiki/Same_origin_policy
        url: 'https://shop.wutzu.com/src/updateUser.php',
        data: { 
            'column_name': $(this).attr('id'), 
            'value': $(this).val(),
            'shopid': MyJSNumVar
        },
        success: function(msg){
            if (msg) {
              toastr.success('Information synced with database');
            } else {
              toastr.warning('There was an issue syncing with the databse, Tray again');
            }
        }
    });

    $(this).addClass('is-valid');
    
});



    $('.file_upload').file_upload();


</script>