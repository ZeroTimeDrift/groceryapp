<?php 
require_once '../src/confs.php';
if (!$_COOKIE['LoggedIn']) {header('Location:'. $siteurl );};
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add Item - Wutzu</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
 <meta http-equiv="x-ua-compatible" content="ie=edge">
 <link rel="stylesheet" type="text/css" href="/css/login.css">
 <link rel="icon" type="image/png" href="/img/circle.png">

 <!-- Font Awesome -->
 <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
 <!-- Bootstrap core CSS -->
 <link href="https://shop.wutzu.com/mdb/css/bootstrap.min.css" rel="stylesheet">
 <!-- Material Design Bootstrap -->
 <link href="https://shop.wutzu.com/mdb/css/mdb.min.css" rel="stylesheet">
 <!-- Your custom styles (optional) -->
 <link href="https://shop.wutzu.com/mdb/css/style.css" rel="stylesheet">
</head>
<body>

  <?php require_once '../src/header.php';?>

  - <br>
  - <br>
  - <br>
  <div class="row">
    <div class="col-md-3 col-lg-4"></div>
    <div class="col-md-6 col-lg-4">
     <!--Main Layout-->
     <main>
      <div class="container-fluid mt-5">
        <form class="border border-light p-5"  method="post" action="/src/addnewitem.php">

          <p class="h4 mb-4 text-center">Add New Item</p>

          <?php echo '<input type="hidden" name="shopid" value="'.$_GET['shopid'].'">' ?>


          <label for="textInput">Item Name</label>
          <input type="text" id="textInput" class="form-control mb-4" placeholder="Apples" name="name" required>

          <label for="textInput">Item Price</label>
          <div class="input-group mb-3">
            <div class="input-group-prepend">
              <span class="input-group-text">£</span>
            </div>
            <input type="text" class="form-control" aria-label="Amount" name="price" required>
          </div>

          <label for="textarea">Item Description</label>
          <textarea id="textarea" class="form-control mb-4" placeholder="Nice Apples to buy" name="about"></textarea>

          <div class="input-group mb-4">
            <div class="input-group-prepend">
              <span class="input-group-text">Image</span>
            </div>
            <div class="custom-file">
              <input type="file" class="custom-file-input" id="fileInput" aria-describedby="fileInput" name="img">
              <label class="custom-file-label" for="fileInput">File Label</label>
            </div>
          </div>

          <button class="btn btn-info btn-block" type="submit">Add</button>
        </form>
      </div>
    </main>
    <!--Main Layout-->

  </div>

  <div class="fixed-action-btn smooth-scroll" style="bottom: 50px; left: 24px;">
    <a onclick="window.history.back();" class="btn-floating btn-large green " data-toggle="tooltip" title="Back">
      <i class="fas fa-arrow-left"></i>
    </a>
  </div>


  <?php require_once '../src/footer.php';?>
</body>
</html>

<!-- SCRIPTS -->
<!-- JQuery -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/jquery-3.4.1.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/mdb.min.js"></script>


<script type="text/javascript">
  $(function () {
      $('[data-toggle="tooltip"]').tooltip()
    })
</script>