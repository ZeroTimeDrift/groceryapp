<?php 
	require_once '../src/confs.php';
	if (!$_COOKIE['LoggedIn']) {header('Location:'. $siteurl );};
?>
<!DOCTYPE html>
<html>
<head>
	<title>Dashboard - Wutzu</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<link rel="stylesheet" type="text/css" href="../css/login.css">
	<link rel="icon" type="image/png" href="../img/circle.png">

	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
	<!-- Bootstrap core CSS -->
	<link href="https://shop.wutzu.com/mdb/css/bootstrap.min.css" rel="stylesheet">
	<!-- Material Design Bootstrap -->
	<link href="https://shop.wutzu.com/mdb/css/mdb.min.css" rel="stylesheet">
	<!-- Your custom styles (optional) -->
	<link href="https://shop.wutzu.com/mdb/css/style.css" rel="stylesheet">
</head>
<body>

<?php require_once '../src/header.php';?>

- <br>
- <br>
- <br>
<div class="col-md-12">
	<h3>Welcome to Wutzu</h3>
	<p>On this page you will see your overall stats</p>

</div>


<?php require_once '../src/footer.php';?>
</body>
</html>

<!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="https://shop.wutzu.com/mdb/js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="https://shop.wutzu.com/mdb/js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="https://shop.wutzu.com/mdb/js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="https://shop.wutzu.com/mdb/js/mdb.min.js"></script>