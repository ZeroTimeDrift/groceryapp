<?php 

require_once '../src/confs.php';
require_once '../src/dbConnect.php';
if (!$_COOKIE['LoggedIn']) {header('Location:'. $siteurl );};

$sql = "SELECT * from shops WHERE shopid = :shopid;";
$getShops = $db->prepare($sql);
$getShops->bindValue(':shopid', $_GET['shopid']);
$getShops->execute();
$shop = $getShops->fetch(PDO::FETCH_ASSOC);

$sql = "SELECT * from items WHERE shopid = :shopid;";
$getItems = $db->prepare($sql);
$getItems->bindValue(':shopid', $_GET['shopid']);
$getItems->execute();
$items = $getItems->fetchAll( PDO::FETCH_ASSOC );

$itemCount = $getItems->rowCount();


$owner = $shop['owner'];

if ($owner != $_COOKIE['token']) {
	header('Location:'. $siteurl . "/shops" );
}


?>
<!DOCTYPE html>
<html>
<head>
	<title>Shop Items - Wutzu</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<link rel="stylesheet" type="text/css" href="/css/login.css">
	<link rel="icon" type="image/png" href="/img/circle.png">

	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
	<!-- Bootstrap core CSS -->
	<link href="https://shop.wutzu.com/mdb/css/bootstrap.min.css" rel="stylesheet">
	<!-- Material Design Bootstrap -->
	<link href="https://shop.wutzu.com/mdb/css/mdb.min.css" rel="stylesheet">
	<!-- Your custom styles (optional) -->
	<link href="https://shop.wutzu.com/mdb/css/style.css" rel="stylesheet">
	<!-- MDBootstrap Datatables  -->
	<link href="https://shop.wutzu.com/mdb/css/addons/datatables.min.css" rel="stylesheet">
</head>
<body>

	<?php require_once '../src/header.php';?>

	- <br>
	- <br>
	- <br>
	<div class="col-md-12">
		<h3>Shop Items</h3>
		<div class="row">
			<div class="col-md-3">
				<div class="card border-primary mb-3 hidden" id="item_details_box" style="max-width: 20rem;" >
					<div class="card-header">Item Details</div>
					<div class="card-body text-primary">
						<h6 class="card-title">Item ID</h6>
						<p class="card-text"><input readonly type="text" id="id" name="id" class="form-control" placeholder="id"><span id="tick"/></p>
						<h6 class="card-title">Name</h6>
						<p class="card-text"><input type="text" id="name" name="name" class="form-control" placeholder="name"><span id="tick"/></p>
						<h6 class="card-title">Price</h6>
						<p class="card-text"><input type="text" id="price" name="price"  class="form-control" placeholder="name"><span id="tick"/></p>
						<h6 class="card-title">Weight</h6>
						<p class="card-text"><input type="text" id="weight" name="weight"  class="form-control" placeholder="name"><span id="tick"/></p>
						<h6 class="card-title">Barcode</h6>
						<p class="card-text"><input type="text" id="barcode" name="barcode"  class="form-control"placeholder="name" ><span id="tick"/></p>
						<button class="btn btn-danger" onclick="closeItemBox()">X</button>
					</div>
				</div>
			</div>

			<div class="col-md-6">
				<table id="dtMaterialDesignExample" class="table table-striped" cellspacing="0" width="100%">
					<thead>
						<tr>
							<th class="th-sm">itemID
							</th>
							<th class="th-sm">Name
							</th>
							<th class="th-sm">Price
							</th>
							<th class="th-sm">Weight
							</th>
							<th class="th-sm">Barcode
							</th>
							<th class="th-sm">Quick Actions
							</th>
						</tr>
					</thead>
					<tbody>
						<?php

						foreach ($items as $item) {
							echo '
							<tr>
							<td>'.$item['itemid'].'</td>
							<td>'.$item['name'].'</td>
							<td>'.$item['price'].'</td>
							<td>'.$item['weight'].'</td>
							<td>'.$item['barcode'].'</td>
							<td><a href="#"><i class="fas fa-edit"></i></a></td>
							</tr>
							';
						}

						?>
						
					</tbody>
					<tfoot>
						<tr>
							<th>itemID
							</th>
							<th>Name
							</th>
							<th>Price
							</th>
							<th>Weight
							</th>
							<th>Barcode
							</th>
							<th>Quick Actions
							</th>
						</tr>
					</tfoot>
				</table>
			</div>


			<div class="col-md-3">
				
			</div>
		</div>
	</div>




	<div class="fixed-action-btn smooth-scroll" style="bottom: 50px; right: 24px;">
		<a href=<?php echo '"/shop/'.$shop['shopid'].'/add-item"'?> class="btn-floating btn-large blue " data-toggle="tooltip" title="Add Items">
			<i class="fas fa-plus"></i>
		</a>
	</div>

</div>
<?php require_once '../src/footer.php';?>
</body>
</html>

<!-- SCRIPTS -->
<!-- JQuery -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/jquery-3.4.1.min.js"></script>
<!-- Bootstrap tooltips -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/popper.min.js"></script>
<!-- Bootstrap core JavaScript -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/bootstrap.min.js"></script>
<!-- MDB core JavaScript -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/mdb.min.js"></script>
<!-- MDBootstrap Datatables  -->
<script type="text/javascript" src="https://shop.wutzu.com/mdb/js/addons/datatables.min.js"></script>
<!-- DataTables Select CSS -->
<link href="https://shop.wutzu.com/mdb/css/addons/datatables-select.min.css" rel="stylesheet">
<!-- DataTables Select JS -->
<script href="https://shop.wutzu.com/mdb/js/addons/datatables-select.min.js" rel="stylesheet"></script>


<script type="text/javascript">

  	// Tooltips Initialization
  	$(function () {
  		$('[data-toggle="tooltip"]').tooltip()
  	})

  	// Material Design example
  	$(document).ready(function () {
  		$('#dtMaterialDesignExample').DataTable();
  		$('#dtMaterialDesignExample_wrapper').find('label').each(function () {
  			$(this).parent().append($(this).children());
  		});
  		$('#dtMaterialDesignExample_wrapper .dataTables_filter').find('input').each(function () {
  			$('input').attr("placeholder", "Search");
  			$('input').removeClass('form-control-sm');
  		});
  		$('#dtMaterialDesignExample_wrapper .dataTables_length').addClass('d-flex flex-row');
  		$('#dtMaterialDesignExample_wrapper .dataTables_filter').addClass('md-form');
  		$('#dtMaterialDesignExample_wrapper select').removeClass(
  			'custom-select custom-select-sm form-control form-control-sm');
  		$('#dtMaterialDesignExample_wrapper select').addClass('mdb-select');
  		$('#dtMaterialDesignExample_wrapper .mdb-select').materialSelect();
  		$('#dtMaterialDesignExample_wrapper .dataTables_filter').find('label').remove();
  	});

  	function addRowHandlers() {
  		var table = document.getElementById("dtMaterialDesignExample");
  		var rows = table.getElementsByTagName("tr");
  		for (i = 0; i < rows.length; i++) {
  			var currentRow = table.rows[i];
  			var createClickHandler = function(row) {
  				return function() {
  					var cell = row.getElementsByTagName("td")[0];
  					var id = cell.innerHTML;
  					//alert("id:" + id);

  					document.getElementById("item_details_box").classList.remove("hidden");
  					document.getElementById("id").classList.remove("is-valid");
  					document.getElementById("name").classList.remove("is-valid");
  					document.getElementById("price").classList.remove("is-valid");
  					document.getElementById("weight").classList.remove("is-valid");
  					document.getElementById("barcode").classList.remove("is-valid");

  					$('input[name=id]').val(row.getElementsByTagName("td")[0].innerHTML);
  					$('input[name=name]').val(row.getElementsByTagName("td")[1].innerHTML);
  					$('input[name=price]').val(row.getElementsByTagName("td")[2].innerHTML);
  					$('input[name=weight]').val(row.getElementsByTagName("td")[3].innerHTML);
  					$('input[name=barcode]').val(row.getElementsByTagName("td")[4].innerHTML);



  				};
  			};
  			currentRow.onclick = createClickHandler(currentRow);
  		}
  	}
  	window.onload = addRowHandlers();

  	function closeItemBox() {
  		document.getElementById("item_details_box").classList.add("hidden");
  	}

  	$('.form-control').change(function(){
    console.log($(this).attr('id') + ":" + $(this).val());

    $.ajax({
        type: 'POST',
        // make sure you respect the same origin policy with this url:
        // http://en.wikipedia.org/wiki/Same_origin_policy
        url: 'https://shop.wutzu.com/src/updateItem.php',
        data: { 
            'column_name': $(this).attr('id'), 
            'value': $(this).val(),
            'itemid': $('input[name=id]').val()
        },
        success: function(msg){
            if (msg) {
              toastr.success('Information synced with database');
            } else {
              toastr.warning('There was an issue syncing with the databse, Tray again');
            }
        }
    });
    $(this).addClass('is-valid');
    location.reload();
    
});

  </script>


 <style type="text/css">
 	.hidden {
 		visibility: hidden !important;
 	}
 </style>