<?php 
	require_once '../src/confs.php';
	if (!$_COOKIE['LoggedIn']) {header('Location:'. $siteurl );};
?>
<!DOCTYPE html>
<html>
<head>
	<title>Add Store - Wutzu</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<link rel="stylesheet" type="text/css" href="../css/login.css">
	<link rel="icon" type="image/png" href="../img/circle.png">

	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
	<!-- Bootstrap core CSS -->
	<link href="https://shop.wutzu.com/mdb/css/bootstrap.min.css" rel="stylesheet">
	<!-- Material Design Bootstrap -->
	<link href="https://shop.wutzu.com/mdb/css/mdb.min.css" rel="stylesheet">
	<!-- Your custom styles (optional) -->
	<link href="https://shop.wutzu.com/mdb/css/style.css" rel="stylesheet">
</head>
<body>

<?php require_once '../src/header.php';?>

- <br>
- <br>
- <br>
  <div class="row">
    <div class="col-md-3 col-lg-4"></div>
    <div class="col-md-6 col-lg-4">
     <!--Main Layout-->
     <main>
      <div class="container-fluid mt-5">
        <form class="border border-light p-5"  method="post" action="/src/addnewShop.php">
          <p class="h4 mb-4 text-center">Add New Shop</p>

            <!-- Name -->
            <div class="md-form mt-3">
                <input type="text" id="materialSubscriptionFormPasswords" name="name" class="form-control" required>
                <label for="materialSubscriptionFormPasswords">Shop Name</label>
            </div>

            <!-- E-mai -->
            <div class="md-form">
                <input type="text" id="materialSubscriptionFormEmail" name="about" class="form-control" required>
                <label for="materialSubscriptionFormEmail">Description</label>
            </div>

            <div class="md-form">
                <input type="text" id="materialSubscriptionFormEmail" name="type" class="form-control" required>
                <label for="materialSubscriptionFormEmail">Shop Type</label>
            </div>


            <!-- Sign in button -->
            <button class="btn btn-info btn-block" type="submit">Create</button>

        </form>
        <!-- Form -->

    </div>

</div>
<!-- Material form subscription -->
  </div>
</main>
<!--Main Layout-->

</div>


<?php require_once '../src/footer.php';?>
</body>
</html>

<!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="https://shop.wutzu.com/mdb/js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="https://shop.wutzu.com/mdb/js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="https://shop.wutzu.com/mdb/js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="https://shop.wutzu.com/mdb/js/mdb.min.js"></script>