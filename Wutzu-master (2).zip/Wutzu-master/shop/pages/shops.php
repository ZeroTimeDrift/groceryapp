<?php 

	require_once '../src/confs.php';
	require_once '../src/dbConnect.php';
	if (!$_COOKIE['LoggedIn']) {header('Location:'. $siteurl );};

?>
<!DOCTYPE html>
<html>
<head>
	<title>Shops - Wutzu</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<link rel="stylesheet" type="text/css" href="../css/login.css">
	<link rel="icon" type="image/png" href="../img/circle.png">

	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
	<!-- Bootstrap core CSS -->
	<link href="https://shop.wutzu.com/mdb/css/bootstrap.min.css" rel="stylesheet">
	<!-- Material Design Bootstrap -->
	<link href="https://shop.wutzu.com/mdb/css/mdb.min.css" rel="stylesheet">
	<!-- Your custom styles (optional) -->
	<link href="https://shop.wutzu.com/mdb/css/style.css" rel="stylesheet">
</head>
<body>

<?php require_once '../src/header.php';?>

- <br>
- <br>
- <br>
<div class="col-md-12">
	<h3>My Shops </h3>
	<p>On this page you will see your shops</p>

	<?php 
	$sql = "SELECT * from shops WHERE owner = :owner;";
	$getShops = $db->prepare($sql);
	$getShops->bindValue(':owner', $_COOKIE['token']);
	$getShops->execute();

	$colours = [
		"primary",
		"danger",
		"warning",
		"success",
	];

	$shopCount = $getShops->rowCount();

	if ($shopCount == 0) {
		echo "You have no shops with us at the moment... why not try adding one";
	} else {
		$shops = $getShops->fetchAll( PDO::FETCH_ASSOC );
		echo '<div class="row">';
		foreach( $shops as $shop ){

			if ($shop['img'] != "") {
				$shopimg = $shop['img'];
			} else {
				$shopimg = "https://shop.wutzu.com/img/blank.png";
			}

			echo '
				<div class="col-md-3">
				<!-- Card Narrower -->
				<div class="card card-cascade narrower">

				  <!-- Card image -->
				  <div class="view view-cascade overlay">
				    <img  class="card-img-top" src="'.$shopimg.'" alt="Card image cap">
				    <a href="/shop/'.$shop['shopid'].'">
				      <div class="mask rgba-white-slight"></div>
				    </a>
				  </div>

				  <!-- Card content -->
				  <div class="card-body card-body-cascade">

				    <!-- Label -->
				    <h5 class="wutzu-text pb-2 pt-1"><i class="fas fa-store"></i> Shop</h5>
				    <!-- Title -->
				    <h4 class="font-weight-bold card-title">'.$shop['name'].'</h4>
				    <!-- Text -->
				    <p class="card-text">'.$shop['about'].'</p>
				    <!-- Button -->
				    <a class="btn btn-unique wutzu-green" href="/shop/'.$shop['shopid'].'">Show Me! </a>

				  </div>

				</div>
				<!-- Card Narrower -->
				</div>
			';
		}
	}

	?>


<div class="fixed-action-btn smooth-scroll" style="bottom: 50px; right: 24px;">
  <a href="/add-shop" class="btn-floating btn-large red " data-toggle="tooltip" title="New Store">
    <i class="fas fa-plus"></i>
  </a>
</div>

</div>
<?php require_once '../src/footer.php';?>
</body>
</html>

<!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="https://shop.wutzu.com/mdb/js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="https://shop.wutzu.com/mdb/js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="https://shop.wutzu.com/mdb/js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="https://shop.wutzu.com/mdb/js/mdb.min.js"></script>

  <script type="text/javascript">

  	// Tooltips Initialization
  	$(function () {
  		$('[data-toggle="tooltip"]').tooltip()
  	})

  </script>