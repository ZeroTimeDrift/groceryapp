<html><head>
<title>404 Error - Wutzu</title>
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta http-equiv="x-ua-compatible" content="ie=edge">
  <link rel="icon" type="image/png" href="/img/circle.png">
<style>
body, html {
  height: 100%;
  margin: 0;
  font: 400 15px/1.8 "Lato", sans-serif;
  color: #777;
}

.bgimg-1, .bgimg-2, .bgimg-3 {
  position: relative;
  opacity: 0.65;
  background-position: center;
  background-repeat: no-repeat;
  background-size: cover;

}
.bgimg-1 {
  background-image: url("/img/city.jpg");
  height: 100%;
}

.caption {
  position: absolute;
  left: 0;
  top: 50%;
  width: 100%;
  text-align: center;
  color: #000;
}

.caption span.border {
  background-color: #111;
  color: #fff;
  padding: 18px;
  font-size: 25px;
  letter-spacing: 10px;
}

.caption span.border2 {
  background-color: #111;
  color: #fff;
  padding: 18px;
}

h3 {
  letter-spacing: 5px;
  text-transform: uppercase;
  font: 20px "Lato", sans-serif;
  color: #111;
}

a {
  color: #a9d728;
}
</style>


</head>
<body>

<div class="bgimg-1">
  <div class="caption">
    <span class="border">404 ERROR</span><br>
    <span class="border">PAGE NOT FOUND</span><br>
    <span class="border2"><a onclick="goBack()" href="#"><< Go Back</a></span>
  </div>
</div>

</body></html>

<script>
function goBack() {
  window.history.back();
}
</script>