<?php 
	require_once '../src/confs.php';
	if (!$_COOKIE['LoggedIn']) {header('Location:'. $siteurl );};
?>
<!DOCTYPE html>
<html>
<head>
	<title>Stats - Wutzu</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<link rel="stylesheet" type="text/css" href="../css/login.css">
	<link rel="icon" type="image/png" href="../img/circle.png">

	<!-- Font Awesome -->
	<link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.8.2/css/all.css">
	<!-- Bootstrap core CSS -->
	<link href="https://shop.wutzu.com/mdb/css/bootstrap.min.css" rel="stylesheet">
	<!-- Material Design Bootstrap -->
	<link href="https://shop.wutzu.com/mdb/css/mdb.min.css" rel="stylesheet">
	<!-- Your custom styles (optional) -->
	<link href="https://shop.wutzu.com/mdb/css/style.css" rel="stylesheet">
</head>
<body>

<?php 
	require_once '../src/header.php';
 	require_once '../src/dbConnect.php';

$sql = "SELECT shopid from shops WHERE TRUE";
$getShops = $db->prepare($sql);
$getShops->execute();
$shopCount = $getShops->rowCount();

$sql = "SELECT userid from users WHERE TRUE;";
$getUsers = $db->prepare($sql);
$getUsers->execute();
$userCount = $getUsers->rowCount();

$sql = "SELECT driverid from drivers WHERE TRUE;";
$getDrivers = $db->prepare($sql);
$getDrivers->execute();
$driverCount = $getDrivers->rowCount();

$sql = "SELECT itemid from items WHERE TRUE;";
$getItems = $db->prepare($sql);
$getItems->execute();
$itemCount = $getItems->rowCount();



?>

- <br>
- <br>
- <br>
<div class="col-md-12">
	<h3>Stats</h3>

	<div class="row">
		<div class="col-md-3">
			<!-- Panel -->
			  <div class="card red mb-4 white-text">
			    <div class="card-body">
			      <div class="pull-right">
			        <i class="fas fa-chart-line"></i>
			      </div>
			      <p>Users</p>
			      <h4><?php echo $userCount ?></h4>
			    </div>
			    <div class="progress md-progress">
			      <div class="progress-bar bg grey darken-3" role="progressbar" style="width: 1%" aria-valuenow=<?php echo '"'.$userCount.'"' ?> aria-valuemin="0" aria-valuemax="300"></div>
			    </div>
			    <div class="card-body">
			      <p class="mb-0">1% total Capacity (300)</p>
			    </div>
			  </div>
			  <!-- Panel -->
		</div>
		<div class="col-md-3">
			<!-- Panel -->
			  <div class="card green mb-4 white-text">
			    <div class="card-body">
			      <div class="pull-right">
			        <i class="fas fa-chart-line"></i>
			      </div>
			      <p>Shops</p>
			      <h4><?php echo $shopCount ?></h4>
			    </div>
			    <div class="progress md-progress">
			      <div class="progress-bar bg grey darken-3" role="progressbar" style="width: 3%" aria-valuenow="3" aria-valuemin="0" aria-valuemax="100"></div>
			    </div>
			    <div class="card-body">
			      <p class="mb-0">3% total Capacity (100)</p>
			    </div>
			  </div>
			  <!-- Panel -->
		</div>
		<div class="col-md-3">
			<!-- Panel -->
			  <div class="card blue mb-4 white-text">
			    <div class="card-body">
			      <div class="pull-right">
			        <i class="fas fa-chart-line"></i>
			      </div>
			      <p>Drivers</p>
			      <h4><?php echo $driverCount ?></h4>
			    </div>
			    <div class="progress md-progress">
			      <div class="progress-bar bg grey darken-3" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
			    </div>
			    <div class="card-body">
			      <p class="mb-0">0% Total Capacity (50)</p>
			    </div>
			  </div>
			  <!-- Panel -->
		</div>
		<div class="col-md-3">
			<!-- Panel -->
			  <div class="card warning-color mb-4 white-text">
			    <div class="card-body">
			      <div class="pull-right">
			        <i class="fas fa-chart-line"></i>
			      </div>
			      <p>Items</p>
			      <h4><?php echo $itemCount ?></h4>
			    </div>
			    <div class="progress md-progress">
			      <div class="progress-bar bg grey darken-3" role="progressbar" style="width: 0%" aria-valuenow="0" aria-valuemin="0" aria-valuemax="100"></div>
			    </div>
			    <div class="card-body">
			      <p class="mb-0">No Max Capacity</p>
			    </div>
			  </div>
			  <!-- Panel -->
		</div>

	</div>


	

<!-- Floating Action Button -->
<!--<div class="fixed-action-btn" style="bottom: 45px; right: 24px;">
  <a class="btn-floating btn-lg red wutzu-green">
    <i class="fas fa-plus"></i>
  </a>
</div>
-->

</div>
<?php require_once '../src/footer.php';?>
</body>
</html>

<!-- SCRIPTS -->
  <!-- JQuery -->
  <script type="text/javascript" src="https://shop.wutzu.com/mdb/js/jquery-3.4.1.min.js"></script>
  <!-- Bootstrap tooltips -->
  <script type="text/javascript" src="https://shop.wutzu.com/mdb/js/popper.min.js"></script>
  <!-- Bootstrap core JavaScript -->
  <script type="text/javascript" src="https://shop.wutzu.com/mdb/js/bootstrap.min.js"></script>
  <!-- MDB core JavaScript -->
  <script type="text/javascript" src="https://shop.wutzu.com/mdb/js/mdb.min.js"></script>