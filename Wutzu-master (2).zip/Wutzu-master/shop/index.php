
<!DOCTYPE html>
<html>
<head>
	<title>Login - Wutzu</title>
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  	<meta http-equiv="x-ua-compatible" content="ie=edge">
	<link rel="stylesheet" type="text/css" href="css/login.css">
	<link rel="icon" type="image/png" href="/img/circle.png">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
</head>
<body>
	<div class="bgimg-1">
		<div class="login-page">
			<div class="form">
				<img src="/img/circle.png" height="50px;">
				<h3>Welcome to Wutzu</h3>
				<form class="register-form" method="post">
					<input type="text" placeholder="name" name="name_create" />
					<input type="password" placeholder="password" name="pass_create" />
					<input type="text" placeholder="email address" name="email_create" />
					<button type="submit" name="register">create</button>
					<p class="message">Already registered? <a href="#">Sign In</a></p>
				</form>
				<form class="login-form" method="post">
					<input type="text" placeholder="email" name="email" />
					<input type="password" placeholder="password" name="pass" />
					<button type="submit" name="login">login</button>
					<p class="message">Not registered? <a href="#">Create an account</a></p>
				</form>
			</div>
		</div>
	</div>
</body>
</html>


<script type="text/javascript">
	$('.message a').click(function(){
		$('form').animate({height: "toggle", opacity: "toggle"}, "slow");
	});
/*
	function registerform() {
	    var http = new XMLHttpRequest();
	    http.open("POST", "<<whereverTheFormIsGoing>>", true);
	    http.setRequestHeader("Content-type","application/x-www-form-urlencoded");
	    var params = "search=" + <<get search value>>; // probably use document.getElementById(...).value
	    http.send(params);
	    http.onload = function() {
	        alert(http.responseText);
	    }
	}
	*/
</script>

<?php 
require_once 'src/confs.php';
require_once 'src/dbConnect.php';

if ($_COOKIE['LoggedIn']) {
	header('Location: https://shop.wutzu.com/dash');
};

if (isset($_POST['register'])) {
	$email = strtolower($_POST['email_create']);
	$pass = $_POST['pass_create'];
	$name = $_POST['name_create'];

	$passhash = password_hash($pass, PASSWORD_DEFAULT);

	$accountCheck = $db->prepare(" SELECT email from users WHERE email = :email");
	$accountCheck->bindValue(':email', $email);
	$accountCheck->execute();
	$accountCheckArray = $accountCheck->rowCount();

	if ($accountCheckArray ==0) {
		$sql = "INSERT INTO `users` (`name`,`email`,`password`,`token`) VALUES (:name, :email, :password,:token)";
		$DBMSG = $db->prepare($sql);
		$DBMSG->bindValue(':name', $name);
		$DBMSG->bindValue(':email', $email);
		$DBMSG->bindValue(':password', $passhash);
		$DBMSG->bindValue(':token', bin2hex(random_bytes(16)));
		$DBMSG->execute();

		//ToDo: Send Activation Email

		echo '<script type="text/javascript">alert("Registration Complete")</script>';
	} else {
		echo '<script type="text/javascript">alert("Account already exists with that email")</script>';
	}
}

if (isset($_POST['login'])) {

	$email = strtolower($_POST['email']);
	$pass = $_POST['pass'];

	$accountCheck = $db->prepare(" SELECT * from users WHERE email = :email");
	$accountCheck->bindValue(':email', $email);
	$accountCheck->execute();
	$accountCheckArray = $accountCheck->rowCount();
	$MSG = $accountCheck->fetch(PDO::FETCH_ASSOC);



	if ($accountCheckArray == 0 ) {
		echo "no Accounts with Email";
		echo '<script type="text/javascript">alert("Sign In Failed")</script>';
	} else {

		if ($MSG['enabled'] == 1) {
			
		

		if (password_verify($pass, $MSG['password'])) {
			echo 'password is correct';

			$cookie_name = "LoggedIn";
			$cookie_value = TRUE;
	    setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day

	    $cookie_name = "name";
	    $cookie_value = $MSG['name'];
	    setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day

	    $cookie_name = "token";
	    $cookie_value = $MSG['token'];
	    setcookie($cookie_name, $cookie_value, time() + (86400 * 30), "/"); // 86400 = 1 day

	    header('Location: https://shop.wutzu.com/dash');

		} else {
			echo 'password is incorrect';
		}

	} else {
		echo '<script type="text/javascript">alert("Thanks for registering, The site is still being built but check back later")</script>';
	}	
	}	
}
?>



