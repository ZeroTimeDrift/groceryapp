<?php

$siteurl = "https://shop.wutzu.com";
$apiurl = "https://api.wutzu.com";


$staff = [
	"29c7baf50ef105999b03a4c7e20d3aef",	//Hevar
	"18966cf2e814b1d91ca92681b6c9700c"	//Joe
];


function isstaff ($token) {
/*
	if (in_array($token, $staff)) {
		return true;
	} else {
		return false;
	}*/	

	return true;
}

?>