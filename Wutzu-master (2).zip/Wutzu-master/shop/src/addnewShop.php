<?php

	$shopname = $_POST['name'];
	$about = $_POST['about'];
	$type = $_POST['type'];

	require_once "dbConnect.php";

	$db = new PDO('mysql:host='.$host.';dbname='.$dbname.';charset=utf8',$username,$password);

	$DBMSG = $db->prepare("INSERT INTO shops (`name`, `owner`, `about`) VALUES (:name, :owner, :about);");
	$DBMSG->bindValue(':name', $shopname);
	$DBMSG->bindValue(':owner', $_COOKIE['token']);
	$DBMSG->bindValue(':about', $about);
	$DBMSG->execute();

	header("Location: /shops");	


?>