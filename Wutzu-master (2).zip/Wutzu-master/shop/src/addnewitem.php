<?php

	$name = $_POST['name'];
	$price = $_POST['price'];
	$about = $_POST['about'];
	$shopid = $_POST['shopid'];

	require_once "dbConnect.php";

	$db = new PDO('mysql:host='.$host.';dbname='.$dbname.';charset=utf8',$username,$password);

	$DBMSG = $db->prepare("INSERT INTO items (`name`, `price`, `description`,`shopid`) VALUES (:name, :price, :about, :shopid);");
	$DBMSG->bindValue(':name', $name);
	$DBMSG->bindValue(':price', $price);
	$DBMSG->bindValue(':about', $about);
	$DBMSG->bindValue(':shopid', $shopid);
	$DBMSG->execute();

	header("Location: /shop/" . $shopid . "/add-item");	


?>