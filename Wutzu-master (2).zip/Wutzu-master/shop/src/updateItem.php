<?php

$column_name = $_POST['column_name'];
$value = $_POST['value'];
$itemid = $_POST['itemid'];


require_once "dbConnect.php";

	$db = new PDO('mysql:host='.$host.';dbname='.$dbname.';charset=utf8',$username,$password);

	$DBMSG = $db->prepare("UPDATE items SET $column_name = :value WHERE itemid = :itemid");
	$DBMSG->bindValue(':value', $value);
	$DBMSG->bindValue(':itemid', $itemid);
	$DBMSG->execute();


echo true;