<?php

$column_name = $_POST['column_name'];
$value = $_POST['value'];
$token = $_COOKIE['token'];


require_once "dbConnect.php";

	$db = new PDO('mysql:host='.$host.';dbname='.$dbname.';charset=utf8',$username,$password);

	$DBMSG = $db->prepare("UPDATE users SET $column_name = :value WHERE token = :token");
	$DBMSG->bindValue(':value', $value);
	$DBMSG->bindValue(':token', $token);
	$DBMSG->execute();


echo true;