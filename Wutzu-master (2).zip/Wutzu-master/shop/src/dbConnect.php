<?php

$host = "127.0.0.1";
$dbname = "wutzu";
$username = "wutzu";
$password = "DaTfO1Rh1HmAcvku";

$db = new PDO('mysql:host='.$host.';dbname='.$dbname.';charset=utf8',$username,$password);

?>


<?php

// pass in the number of seconds elapsed to get hours:minutes:seconds returned
function time_elapsed_B($secs){
    $bit = array(
        ' y'        => $secs / 31556926 % 12,
        ' w'        => $secs / 604800 % 52,
        ' d'        => $secs / 86400 % 7,
        ' h'        => $secs / 3600 % 24,
        ' m'    => $secs / 60 % 60,
        ' s'    => $secs % 60
        );
        
    foreach($bit as $k => $v){
        if($v > 1)$ret[] = $v . $k;
        if($v == 1)$ret[] = $v . $k;
        }
    array_splice($ret, count($ret)-1, 0, 'and');
    $ret[] = 'ago.';
    
    return join(' ', $ret);
    }

function sanitize($input) {
    return $input;
}

?>