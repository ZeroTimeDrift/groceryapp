<!-- Footer -->
<footer class="page-footer font-small elegant-color-dark fixed-bottom">

  <!-- Copyright -->
  <div class="footer-copyright text-center py-3">© 2019 Copyright:
    <a href="https://mdbootstrap.com/education/bootstrap/"> Wutzu.com</a>
  </div>
  <!-- Copyright -->

</footer>
<!-- Footer -->