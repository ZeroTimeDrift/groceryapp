<?php require_once 'confs.php'; ?>
<!--Main Navigation-->
<header>

  <nav class="navbar fixed-top navbar-expand-lg navbar-dark elegant-color-dark scrolling-navbar">
    <a class="navbar-brand" href="#">
      <img src="/img/circle.png" height="30" class="d-inline-block align-top"
      alt="mdb logo"> Wutzu.com
    </a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent"
    aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="navbarSupportedContent">
    <ul class="navbar-nav mr-auto">
      
      <?php if($_SERVER['REQUEST_URI'] == "/dash") {echo '<li class="nav-item active">';} else {echo '<li class="nav-item">';} ?>
        <a class="nav-link" href="/dash">Home <span class="sr-only">(current)</span></a>
      </li>
      <?php if($_SERVER['REQUEST_URI'] == "/shops") {echo '<li class="nav-item active">';} else {echo '<li class="nav-item">';} ?>
        <a class="nav-link" href="/shops">My Shops</a>
      </li>
      <?php if($_SERVER['REQUEST_URI'] == "/driving") {echo '<li class="nav-item active">';} else {echo '<li class="nav-item">';} ?>
        <a class="nav-link" href="/driving">My Driving</a>
      </li>

      <?php 
      if (isstaff($_COOKIE['token'])) {
        if($_SERVER['REQUEST_URI'] == "/system-stats") {echo '<li class="nav-item active">';} else {echo '<li class="nav-item">';}
        echo '
          <a class="nav-link" href="/system-stats">Stats</a>
        </li>
        ';
      }
      ?>

    </ul>
    <ul class="navbar-nav nav-flex-icons">
      <li class="nav-item">
        <a class="nav-link" href="/account">Welcome: <b style="color: #a9d728"><?php echo $_COOKIE["name"];?></b></a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/logout"><i class="fas fa-sign-out-alt"></i></a>
      </li>
    </ul>
  </div>
</nav>

</header>
<!--Main Navigation-->