<?php

$column_name = $_POST['column_name'];
$value = $_POST['value'];
$shopid = $_POST['shopid'];


require_once "dbConnect.php";

	$db = new PDO('mysql:host='.$host.';dbname='.$dbname.';charset=utf8',$username,$password);

	$DBMSG = $db->prepare("UPDATE shops SET $column_name = :value WHERE shopid = :shopid");
	$DBMSG->bindValue(':value', $value);
	$DBMSG->bindValue(':shopid', $shopid);
	$DBMSG->execute();


echo true;